const express = require('express');
const router = express.Router();

let users = [
  {id:1,name:'ناصر',email:'user1@example.com',wallet:{balance:500}},
  {id:2,name:'سارة',email:'user2@example.com',wallet:{balance:300}},
  {id:3,name:'علي',email:'user3@example.com',wallet:{balance:200}}
];

let transactions = [];

router.post('/deposit',(req,res)=>{
  const {userId, amount} = req.body;
  const user = users.find(u=>u.id===userId);
  if(!user) return res.status(404).json({error:'User not found'});
  user.wallet.balance += amount;
  transactions.push({id:transactions.length+1,userId,type:'deposit',amount,status:'completed'});
  res.json({ok:true,balance:user.wallet.balance});
});

router.post('/withdraw',(req,res)=>{
  const {userId, amount} = req.body;
  const user = users.find(u=>u.id===userId);
  if(!user) return res.status(404).json({error:'User not found'});
  if(user.wallet.balance<amount) return res.status(400).json({error:'رصيد غير كافي'});
  user.wallet.balance -= amount;
  transactions.push({id:transactions.length+1,userId,type:'withdraw',amount,status:'completed'});
  res.json({ok:true,balance:user.wallet.balance});
});

router.post('/transfer',(req,res)=>{
  const {fromUserId,toUserId,amount} = req.body;
  const fromUser = users.find(u=>u.id===fromUserId);
  const toUser = users.find(u=>u.id===toUserId);
  if(!fromUser || !toUser) return res.status(404).json({error:'User not found'});
  if(fromUser.wallet.balance<amount) return res.status(400).json({error:'رصيد غير كافي'});
  fromUser.wallet.balance -= amount;
  toUser.wallet.balance += amount;
  transactions.push({id:transactions.length+1,userId:fromUserId,type:'transfer-out',amount,status:'completed'});
  transactions.push({id:transactions.length+1,userId:toUserId,type:'transfer-in',amount,status:'completed'});
  res.json({ok:true});
});

router.get('/all',(req,res)=>res.json({users,transactions}));

module.exports = router;