const express = require('express');
const router = express.Router();
const { users, transactions } = require('./wallet');

router.get('/users',(req,res)=>res.json(users));
router.get('/transactions',(req,res)=>res.json(transactions));

module.exports = router;